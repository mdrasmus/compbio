# a directory must contain a __init__.py in order to be a python package



#import rutil as util
#from rutil import svg
