SPIDIR - Species Informed Distance-based Reconstruction
Matt Rasmussen 2007


PROGRAM USAGE
=============================================================================

Usage: spidir.py [OPTION] 

  SPIDIR v0.7 (beta) Sept 2007
  SPecies Informed DIstanced-base Reconstruction
  Matt Rasmussen
    

Options
  -o,--out <output prefix>
    The prefix for all output files

  -d,--dist <distance file>
    Build a tree from a phylip distance matrix file

  -l,--labels <gene labels file>
    Supply gene names for the rows and cols of a distance matrix

  -p,--param <param file>
    When training this is used as an output file

  -s,--stree <species tree>
    species tree (newick format)

  -S,--smap <gene2species map>
    mapping of gene names to species names

Search options
  -R,--search <method>
    tree search method.  Options are:
        mcmc   - Markov Chain Monte Carlo (default)
        greedy - Phylip-like search
        none   - no search

  -T,--tree <propose tree>

  --tops <proposed topologies>

  -i,--iters <MCMC iterations>

  -I,--depth <greedy NNI depth>

  --rerootprob <probability of reroot>

  --nchains <number of chains>

  --eprune <exhaustive prune>

  --searchtest 

  --regrafts <regraph iterations>

  --regraftloop <number of branches to try for each regraft>

Training options
  -t,--train 
    Run SPIDIR in training mode.  

  -z,--trainstats <training stats prefix>

Parameter options
  -D,--dupprob <probability of duplication>

  --predupprob <probability of pre-speciation duplication>

  -L,--lossprob <probability of loss>

  --errorcost <error cost>

  --famprob True|False

Miscellaneous options
  --correcttree <correct tree newick>

  -V,--debug <level>
    set SPIDIR debug level

  --python_only 

  --parsimony 

  --mlhkydist 

  --bgfreq <background base frequencies>

  --tsvratio <transition/transversion ratio>

  -P,--paths <files path>
    colon separated paths used to search for data files

  -h,--help 
    display program usage



EXAMPLES
=============================================================================

Examples for how to run SPIDIR are given in spidir-examples/*.sh.

1. training evolutionary model (execute in spidir-examples/ directory)

    spidir.py -t -p model.param -s yeast.stree -S yeast.smap yeast-one2one/*.nt.tree
    
    Trains a model (saved in the file 'model.param') from the genes trees 
    'yeast-one2one/*.nt.tree' using a species tree 'yeast.stree' and a gene to 
    species mapping 'yeast.smap'.
    
2. gene tree reconstruction

    spidir.py -p yeast.param -s yeast.stree -S yeast.smap \\
        -d yeast-one2one/0.nt.align.dist \\
        -l yeast-one2one/0.nt.align
        
    Reconstructs the gene tree for the pair-wise distance matrix 
    'yeast-one2one/0.nt.align.dist' with gene names in 'yeast-one2one/0.nt.align'
    using a model of evolution 'model.param' (must be created by training first),
    a specie stree 'yeast.stree' and a gene to species mapping 'yeast.smap'.


FILE FORMATS
================================================================================

*.stree     - Rooted species trees (newick format)
*.smap      - Gene name to species name mapping file (tab delimited)
              First column is an pattern for a gene name, the second column 
              is the corresponding species name.  The only patterns that are 
              currently allowed are:
               prefixes:   CG*      dmel
               suffix:     *_dmel   dmel
               exact:      CG1234   dmel

*.param - SINDIR parameter file.  Learned distibutions are saved in these 
          files.  First column is branch name or 'baserate'.  Second and third 
          columns are parameters for a distributions: mean, 
          standard deviation for branches and alpha, beta for baserate (aka: 
          family rate). Branches are named by the node directly below them in
          the tree.  Internal branches are numbered by a pre-order traversal of
          the tree (the root is numbered 1).


*.fasta         - Fasta file with original peptide sequences
*.pep.align     - Multiple alignment of peptides in *.fasta
*.nt.align      - Nucleotide alignments.  These were created by mapping each
                  pepeptide alignment (*.pep.align) into a nucleotide alignment
                  by replacing each amino-acid with the original codon from the
                  coding sequence and every gap with three gaps.
*.dist          - Pair-wise gene distances in PHYLIP format.  Distances are
                  estimated using HKY from *.nt.align (see Note)
*.correct.tree  - Correct tree topology derived from synteny (no branch lengths)
*.nt.tree       - Gene tree (newick) with PHYML fitted branch lengths on 
                  the correct topology (*.correct.tree) using nucleotide
                  alignments (*.nt.align).  Used for SPIDIR training.


Note: PHYLIP distance files have a restiction of 10 characters for the gene
name.  Some programs allow up to 30 characters but then require 2 spaces between
the gene name and the distance values.  Thus, the most portable format is to
limit gene names to 8 characters and always use 2 spaces of separation.  Because
of these limitations, we have chosen not to write gene names in distance files
(*.hky.dist) altogether.  Instead place holders are used ('_______1',
'_______2', etc) and the corresponding alignment file (*.nt.align) is used to
indicate gene names (FASTA keys appear in the same order as rows in the distance
matrix).

