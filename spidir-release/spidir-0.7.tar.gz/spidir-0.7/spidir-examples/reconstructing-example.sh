#!/bin/sh
#
# SPIDIR
#
# Here is an example of how to reconstruct a gene tree using SPIDIR's model
#

spidir.py -p yeast.param -s yeast.stree -S yeast.smap \
    -d yeast-one2one/0.nt.align.dist \
    -l yeast-one2one/0.nt.align \
    -o mytree

# this will create two files 'mytree.tree' (newick format) and 'mytree.debug.tab'
# (a tabular file with statistics on each evaluated tree)

