#!/bin/sh
#
# SPIDIR
#
# Here is an example of how to train a SPIDIR model from a set of gene trees
#

spidir.py -t -p model.param -s yeast.stree -S yeast.smap \
    yeast-one2one/*.nt.tree

# this will create a file called 'model.param' that should contain roughly the
# same parameters as the supplied 'yeast.param' file.
